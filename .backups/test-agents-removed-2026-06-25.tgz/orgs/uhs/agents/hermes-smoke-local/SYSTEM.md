# System Context

**Organization:** Utopia Home Staging
**Description:** Luxury home staging company in Las Vegas, NV. Serves real estate agents with occupied and vacant staging, consultations, and AI-powered staging reports.
**Timezone:** America/Los_Angeles
**Orchestrator:** jarvis-orchestrator
**Dashboard:** (not configured)
**Communication Style:** direct and professional
**Day Mode:** 06:00 - 20:00
**Framework:** cortextOS Node.js

---

## Team Roster

> This section is populated during onboarding. For the live roster:
```bash
cortextos list-agents
```

## Agent Health

```bash
cortextos bus read-all-heartbeats
```

## Communication

- Agent-to-agent: `cortextos bus send-message <agent> <priority> "<text>"`
- Telegram to user: `cortextos bus send-telegram <chat_id> "<text>"`
- React to a Telegram message (single emoji ack, no verbal noise): `cortextos bus react-telegram <chat_id> <message_id> 👍`
- Check inbox: `cortextos bus check-inbox`
